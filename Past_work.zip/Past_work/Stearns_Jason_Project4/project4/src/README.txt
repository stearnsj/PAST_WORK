The order of config.txt is:
dimensions, swarm size, iterations,  c1, c2.

The order of config2.txt is:
dimensions, swarm size, iterations, gama, alpha, betamin

change these numbers in these files to change the exicution of the program.
config.txt is for particle swarm and config2.txt is for fire-fly algorithm

*****dimensions and swarmsize must be integers or the program will not exicute correctly.

WHen running the code exicute you can use visual studio 2015.

when the code is executed it will create two files PSOresults.csv and FFresults.csv which are
two csv files containing the results of the execution